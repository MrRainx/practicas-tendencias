import React from 'react';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Home from './Home';
import ImagenS3 from './ImagenS3';
import Firebase from './Firebase';
import NavBar from './Navbar';


function App() {

  return (
    <>
      <Router>
        <NavBar />
        <>
          <Switch>

            <Route path="/" exact component={Home} />
            <Route path="/imagens3" exact component={ImagenS3} />
            <Route path="/firebase" exact component={Firebase} />

          </Switch>
        </>
      </Router>
    </>
  )
}

export default App;
