import React, { useEffect } from 'react'
//import firebase from "../firebase";
const inProgress = true;

const Firebase = () => {

    useEffect(() => {
        /*
        console.log('EFFECT')
        firebase.firestore()
            .collection('usuarios')
            .onSnapshot((snapshot) => {
                console.log('SNAPSHOT:', snapshot)
                snapshot.docs.map((doc) => {
                    console.log(doc)
                })
            })
*/
    }, [])

    if (inProgress) return 'AHORITA NO... VUELVA MAS TARDE :v';

    return (
        <div className="text-center">
            <h1 className="display-4">Ejemplo de Firebase</h1>
        </div>
    )
}

export default Firebase
