import React from 'react'
import { useHistory } from 'react-router-dom'

const Home = () => {
    const history = useHistory()


    function handleOnClick(event) {
        const { name } = event.target

        history.push(`/${name}`)
    }


    return (
        <div>
            <button name="imagens3" onClick={handleOnClick}>Imagenes en S3</button>
            <button name="firebase" onClick={handleOnClick}>Firebase</button>
        </div>
    )
}

export default Home
